"""
Engine package for One‑Prompt‑SaaS.

This package contains modules for each supported AI engine, along with
a selector that chooses the appropriate engine based on user input or
configuration. Add new modules here to support additional providers.
"""

__all__ = ["gpt", "claude", "selector"]