"""
Engine selection logic.

This module chooses the appropriate engine for generating code based on
user input or environment defaults. If the user specifies an `engine`
parameter, that engine is used; otherwise the default is read from
the `DEFAULT_ENGINE` environment variable or falls back to GPT.
"""

import os
from typing import Optional, Dict, Any

from .gpt import generate_code as gpt_generate
from .claude import generate_code as claude_generate


def generate_code(prompt: str, engine: Optional[str] = None) -> Dict[str, Any]:
    """Select an engine and generate code.

    Args:
        prompt: A natural language description of the desired application.
        engine: Explicit engine name (`gpt` or `claude`). If None,
            fallback to `DEFAULT_ENGINE` environment variable, or
            `gpt` as the final default.

    Returns:
        A dictionary containing the generated files and the engine used.
    """
    selected_engine = engine or os.getenv("DEFAULT_ENGINE", "gpt")

    # Normalise engine names
    selected_engine = selected_engine.lower().strip()

    if selected_engine == "claude":
        return claude_generate(prompt)
    else:
        # default to GPT
        return gpt_generate(prompt)