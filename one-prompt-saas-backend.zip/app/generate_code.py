"""
Generation logic for One‑Prompt‑SaaS.

This module orchestrates the process of converting a natural language prompt
into a runnable application and deploying it. The process involves two
steps:

1. Selecting an AI engine to generate source code from the prompt.
2. Deploying the generated files to a hosting provider.

In this skeleton implementation, the AI engines return stubbed code and the
deployment function returns a placeholder URL. Update these components
to use real AI services and deployment APIs.
"""

from typing import Optional, Dict, Any

from .engines.selector import generate_code as select_engine
from .deploy import deploy_to_render


def generate_app_code(prompt: str, engine: Optional[str] = None) -> Dict[str, Any]:
    """Generate application code from a prompt and deploy it.

    Args:
        prompt: Natural language description of the desired app.
        engine: Name of the engine to use (e.g. "gpt" or "claude"). If
            omitted, the default engine will be used.

    Returns:
        A dictionary containing at least a `deployment_url` key, and
        optionally other information such as the generated files and engine
        metadata.
    """

    # Generate code using the selected AI engine. This returns a
    # dictionary with a `files` key containing a mapping of file names to
    # file contents and an `engine` key identifying which engine was used.
    engine_output = select_engine(prompt, engine)

    # Deploy the generated files. The deploy function should accept a
    # dictionary mapping file names to file contents and return the URL
    # where the application is hosted. In this skeleton, the function
    # returns a dummy URL.
    deployment_url = deploy_to_render(engine_output.get("files", {}))

    return {
        "deployment_url": deployment_url,
        "engine": engine_output.get("engine"),
        "files": engine_output.get("files"),
    }