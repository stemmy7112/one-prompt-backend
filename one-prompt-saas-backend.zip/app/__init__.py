"""Application package initialization.

This file marks the `app` directory as a Python package. It can also be
used to set up package‑wide configuration if needed in the future.
"""

__all__ = []