"""
Utility functions for One‑Prompt‑SaaS.

This module contains helper functions that might be useful for packaging,
zipping, or otherwise manipulating the generated files. Currently it
contains a simple stub; extend it as needed.
"""

from typing import Dict


def package_files(files: Dict[str, str]) -> Dict[str, str]:
    """Prepare files for deployment.

    In a real implementation you might compress the files into a zip
    archive, perform static analysis, or otherwise modify the file set
    before deployment. This stub simply returns the input unchanged.

    Args:
        files: A dictionary mapping file names to their contents.

    Returns:
        The same dictionary of files.
    """
    return files