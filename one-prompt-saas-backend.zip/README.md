# One‑Prompt‑SaaS Backend

This repository provides a skeleton backend service for the One‑Prompt‑SaaS platform. It uses
FastAPI to expose a simple `/generate` endpoint. Given a natural language prompt describing
an application, the service returns a URL where the generated app is deployed. The goal of
this skeleton is to give you a starting point; you'll need to implement the
language‑model integration and deployment logic yourself.

## Features

* **FastAPI** for a fast, modern API experience.
* Support for selecting between multiple AI engines (e.g. GPT‑4 or Claude) via the `engine` field.
* Placeholder deployment function (`deploy_to_render`) ready to integrate with Render or other hosts.

## Setup

1. **Clone** the repository to your machine.
2. **Install dependencies** using pip:

   ```bash
   pip install -r requirements.txt
   ```

3. **Create a `.env` file** based on `.env.example` and fill in your API keys. At minimum you
   should set `OPENAI_API_KEY`. If you have access to Anthropic's Claude API, set
   `CLAUDE_API_KEY` and change `DEFAULT_ENGINE` if desired.

4. **Run the server** locally:

   ```bash
   uvicorn main:app --reload --port 8000
   ```

5. **Test the endpoint** by sending a POST request to `http://localhost:8000/generate` with JSON
   similar to the following:

   ```json
   {
     "prompt": "A to‑do app with user login and dark mode",
     "engine": "gpt"
   }
   ```

   The server will respond with a JSON object containing a `url` field. In this skeleton,
   the URL is a placeholder. You'll need to update `app/deploy.py` to perform a real
   deployment.

## Deployment

The `deploy_to_render` function in `app/deploy.py` currently returns a dummy URL. Replace
this implementation with calls to your hosting provider (Render, Vercel, etc.)
once you have generated the code for your app. Similarly, `app/generate_code.py`
should be updated to call the appropriate language model API (OpenAI or Anthropic) and
parse its output into a set of files ready for deployment.

## License

This skeleton is provided under the MIT License. Feel free to modify and extend it to
suit your needs.