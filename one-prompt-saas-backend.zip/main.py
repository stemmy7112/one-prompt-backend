"""
Main entry point for the One‑Prompt‑SaaS backend.

This module defines a simple FastAPI application that exposes a single
endpoint, `/generate`. Clients send a JSON payload containing a natural
language prompt and an optional `engine` field indicating which AI
model to use (e.g. `gpt` or `claude`). The backend delegates
generation and deployment to helper functions in the `app` package.

The current implementation is a skeleton to get you started; it
does not actually call language models or deploy code. You will need
to fill in the details in `app/generate_code.py` and
`app/deploy.py` when integrating with OpenAI, Anthropic and your
hosting provider.
"""

from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Dict, Any

from app.generate_code import generate_app_code


app = FastAPI(title="One‑Prompt‑SaaS Backend")


class PromptInput(BaseModel):
    """Schema for incoming prompt requests.

    Attributes:
        prompt: The natural language description of the desired app.
        engine: Optionally specify which engine to use. If omitted,
            the default engine from the environment will be used.
    """

    prompt: str
    engine: Optional[str] = None


@app.post("/generate")
async def generate(prompt_input: PromptInput) -> Dict[str, Any]:
    """Generate and deploy an application from a prompt.

    Args:
        prompt_input: A `PromptInput` instance containing the user's prompt
            and optionally the engine to use.

    Returns:
        A JSON object with a `status` field and a `url` pointing to the
        deployed application. In this skeleton implementation, the URL
        returned is a placeholder. Update `app/generate_code.py` and
        `app/deploy.py` to produce real deployments.
    """

    result = generate_app_code(prompt_input.prompt, prompt_input.engine)
    return {"status": "success", "url": result.get("deployment_url", "")}